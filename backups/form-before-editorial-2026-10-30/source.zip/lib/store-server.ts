import { env } from 'cloudflare:workers';
import { headers } from 'next/headers';
import { configSchema, textFields, type StoreConfig } from './store-config';
import products from '../data/default-products.json';
export const defaults:StoreConfig=configSchema.parse({brand:'form',currency:'USD',texts:Object.fromEntries(Object.entries(textFields).map(([k,v])=>[k,v[1]])) as StoreConfig['texts'],storyImage:'https://images.unsplash.com/photo-1449247709967-d4461a6a6103?auto=format&fit=crop&w=1300&q=85',contacts:{whatsapp:'',phone:'',email:'',facebook:'',instagram:'',address:''},products});
export function db(){if(!env.DB)throw new Error('Storage is unavailable');return env.DB}
export async function getSettings(){const row=await db().prepare('SELECT value, revision, updated_at FROM store_settings WHERE id=1').first<{value:string,revision:number,updated_at:string}>();return row?{config:configSchema.parse(JSON.parse(row.value)),revision:row.revision,updatedAt:row.updated_at}:{config:defaults,revision:0,updatedAt:null}}
export async function isAdmin(){const h=await headers();const id=h.get('oai-authenticated-user-id');const email=h.get('oai-authenticated-user-email')?.toLowerCase();if(!id||!email)return false;const existing=await db().prepare('SELECT user_id FROM store_admin WHERE id=1').first<{user_id:string}>();if(existing)return existing.user_id===id;
  const local=import.meta.env.DEV&&id==='local_seedy'&&email==='seedy@sites.test';
  if(email!=='academic.mojaru2026@gmail.com'&&!local)return false;
  await db().prepare('INSERT OR IGNORE INTO store_admin (id,user_id) VALUES (1,?)').bind(id).run();
  const owner=await db().prepare('SELECT user_id FROM store_admin WHERE id=1').first<{user_id:string}>();return owner?.user_id===id;
}
export function sameOrigin(req:Request){return req.headers.get('origin')===new URL(req.url).origin}
export function json(value:unknown,status=200){return Response.json(value,{status,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}})}
export function htmlResponse(html:string){return new Response(html,{headers:{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'strict-origin-when-cross-origin','Content-Security-Policy':"frame-ancestors 'self'; object-src 'none'; base-uri 'self'"}})}

