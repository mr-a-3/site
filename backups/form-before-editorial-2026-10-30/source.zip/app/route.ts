import html from '../data/storefront-html';
import {getSettings, htmlResponse} from '../lib/store-server';
export const dynamic='force-dynamic';
export async function GET(){const {config}=await getSettings();const serialized=JSON.stringify(config).replace(/</g,'\\u003c').replace(/\u2028/g,'\\u2028').replace(/\u2029/g,'\\u2029');return htmlResponse(html.replace('<script src="app.js"',`<script>window.STORE_DATA=${serialized}</script><script src="app.js"`))}
