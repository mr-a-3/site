import { z } from 'zod';
const image = z.string().max(2000).refine(v => /^photo-[a-zA-Z0-9-]+$/.test(v) || /^\/media\/[a-f0-9-]+\.(png|jpg|webp|gif)$/.test(v) || (()=>{try{return new URL(v).protocol==='https:'}catch{return false}})(), 'Use an HTTPS image URL or upload an image.');
export const textFields = {
  announcement: ['.announcement > span:nth-child(2)', 'A new point of view ↗'],
  heroEyebrow: ['.hero-copy .eyebrow', 'THE NEXT EVERYDAY / 01'],
  heroTitle: ['', 'Beyond'], heroAccent: ['', 'the ordinary.'],
  heroDescription: ['.hero-copy > p', 'Considered objects. A different perspective.'],
  heroButton: ['', 'Discover the edit'],
  heroNote: ['.hero-note', 'SELECTED WITH INTENTION.'],
  collectionEyebrow: ['.section-heading .eyebrow', '01 / THE COLLECTION'],
  collectionTitle: ['#collection-title', 'Selected. Not ordinary.'],
  collectionNote: ['.section-heading > p', 'SIX OBJECTS. ONE POINT OF VIEW.'],
  collectionFooter: ['.collection-footnote', 'Made for your everyday. Chosen for what’s next.'],
  storyEyebrow: ['.story-copy .eyebrow', '02 / OUR PERSPECTIVE'],
  storyTitle: ['.story-copy h2', 'Not more things.\nThe right things.'],
  storyDescription: ['.story-copy > p', 'Distinctive shapes. Useful details. Nothing extra.'],
  storyImageLabel: ['.image-tag', 'LESS, BUT BETTER.'],
  newsletterEyebrow: ['.newsletter .eyebrow', 'THE NEXT CHAPTER'],
  newsletterTitle: ['.newsletter h2', 'Ahead of the ordinary.'],
  navShop: ['.desktop-nav a:nth-child(1)', 'Shop all'], navLiving: ['.desktop-nav a:nth-child(2)', 'Living'],
  navEveryday: ['.desktop-nav a:nth-child(3)', 'Everyday'], navAbout: ['.desktop-nav a:nth-child(4)', 'Our approach'],
  valueOne: ['.value-strip > span:nth-child(1)', '✳ Considered design'], valueTwo: ['.value-strip > span:nth-child(2)', '↗ Everyday, reimagined'],
  valueThree: ['.value-strip > span:nth-child(3)', '◇ Quiet distinction'], valueFour: ['.value-strip > span:nth-child(4)', '○ The next essentials'],
  footerCopyright: ['.footer-bottom > span:first-child', '© 2026 · Storefront design concept']
} as const;
const phone=z.string().max(30).refine(v=>!v || /^\+?[0-9 ()-]{7,25}$/.test(v),'Enter a number with country code.');
const social=(hosts:string[])=>z.string().max(2000).refine(v=>{if(!v)return true;try{const u=new URL(v);return u.protocol==='https:'&&hosts.includes(u.hostname)}catch{return false}},'Use the full HTTPS profile URL.');
export const configSchema=z.object({brand:z.string().trim().min(1).max(40),currency:z.enum(['USD','BDT','EUR','GBP','INR']),texts:z.object(Object.fromEntries(Object.keys(textFields).map(k=>[k,z.string().max(500)])) as Record<keyof typeof textFields,z.ZodString>),storyImage:image,contacts:z.object({whatsapp:phone,phone:phone,phone2:phone.default(''),email:z.union([z.literal(''),z.string().email().max(200)]),facebook:social(['facebook.com','www.facebook.com','m.facebook.com']),instagram:social(['instagram.com','www.instagram.com']),address:z.string().max(500)}),products:z.array(z.object({id:z.number().int().positive(),name:z.string().trim().min(1).max(100),category:z.enum(['Tech','Living','Everyday']),type:z.string().max(200),price:z.number().finite().min(0).max(10000000).refine(n=>Math.abs(n*100-Math.round(n*100))<.000001,'Use at most two decimal places.'),image,badge:z.string().max(60),colors:z.array(z.string().regex(/^#[0-9a-fA-F]{6}$/)).max(6),description:z.string().max(2000)})).min(1).max(100).refine(p=>new Set(p.map(x=>x.id)).size===p.length,'Product IDs must be unique.')});
export type StoreConfig=z.infer<typeof configSchema>;

