// Intentionally empty by default.
// Add Drizzle tables here when the site actually needs a database.
// See examples/d1/db/schema.ts for an opt-in example.
import { sqliteTable, text, integer } from 'drizzle-orm/sqlite-core';
export const storeSettings = sqliteTable('store_settings', { id: integer('id').primaryKey(), value: text('value').notNull(), revision: integer('revision').notNull(), updatedAt: text('updated_at').notNull() });
export const storeAdmin = sqliteTable('store_admin', { id: integer('id').primaryKey(), userId: text('user_id').notNull() });
